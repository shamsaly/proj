﻿using Microsoft.EntityFrameworkCore;
using WebApplication14.Data;
using WebApplication14.Specification;

namespace WebApplication14.Generaric
{
    public class GeneraicRepositoty<T> : IGeneraicRepository<T> where T : class
    {
        private readonly StoreDbContext storeDb;

        public GeneraicRepositoty(StoreDbContext storeDb)
        {
            
             this.storeDb = storeDb;
        }


        public async Task Additem(T item)
        {
           await storeDb.AddAsync(item);
            await storeDb.SaveChangesAsync();
        }

        public async Task Delete(T item)
        {
            storeDb.Remove(item);
            await storeDb.SaveChangesAsync();
        }

        public async Task<IEnumerable<T>> GetAllWithSpec(ISpecifaction<T> spec)
        {
            return await SpecifucationEvalouater<T>.GetQuerry(storeDb.Set<T>(), spec).ToListAsync();
        }

        public async Task<T> GetByIDWithSpec(ISpecifaction<T> spec)
        {
            return await SpecifucationEvalouater<T>.GetQuerry(storeDb.Set<T>(), spec).FirstOrDefaultAsync();
        }

        public async Task update(T item)
        {
            storeDb.Set<T>().Update(item);
            await storeDb.SaveChangesAsync();
        }
    }
}
