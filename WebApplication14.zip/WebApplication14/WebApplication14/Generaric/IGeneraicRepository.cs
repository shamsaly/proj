﻿using Microsoft.AspNetCore.Cors.Infrastructure;
using WebApplication14.Specification;

namespace WebApplication14.Generaric
{
    public interface IGeneraicRepository<T> where T : class
    {
        Task<IEnumerable<T>> GetAllWithSpec(ISpecifaction<T>spec);

        Task<T> GetByIDWithSpec(ISpecifaction<T> spec);

        Task Additem(T item);
        Task update(T item);
        Task Delete(T item);



    }
}
