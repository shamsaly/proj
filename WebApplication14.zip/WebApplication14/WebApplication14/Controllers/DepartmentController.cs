﻿using AutoMapper;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using WebApplication14.Dto;
using WebApplication14.Generaric;
using WebApplication14.Models;

namespace WebApplication14.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class DepartmentController : ControllerBase
    {
        private readonly IGeneraicRepository<Departtment> departmentrepo;
        private readonly IMapper mapper;

        public DepartmentController(IGeneraicRepository<Departtment>departmentrepo,IMapper mapper)
        {
            this.departmentrepo = departmentrepo;
            this.mapper = mapper;
        }
        [HttpPost]
        public async Task<ActionResult>AddDepartment(DepartmentCreateDto dto)
        {

            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var Department = mapper.Map<DepartmentCreateDto, Departtment>(dto);
            await departmentrepo.Additem(Department);
            return Ok("done");

        }




    }
}
