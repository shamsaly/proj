﻿using AutoMapper;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using WebApplication14.Dto;
using WebApplication14.Generaric;
using WebApplication14.Models;
using WebApplication14.Specification;

namespace WebApplication14.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PatientController : ControllerBase
    {
        private readonly IGeneraicRepository<Patiant> patientrepo;
        private readonly IGeneraicRepository<Doctor> doctorrepo;
        private readonly IMapper mapper;

        public PatientController(IGeneraicRepository<Patiant> patientrepo, IGeneraicRepository<Doctor> doctorrepo, IMapper mapper)
        {
            this.patientrepo = patientrepo;
            this.doctorrepo = doctorrepo;
            this.mapper = mapper;
        }

        [HttpPost]
        public async Task<ActionResult> AddPatient(PatientCreateDTO dto)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            var patient = mapper.Map<PatientCreateDTO, Patiant>(dto);
            if (dto.doctorid.Count == 0)
            {
                return NotFound("doc id not found");
            }
            else
            {
                foreach (var id in dto.doctorid)
                {
                    var spec = new DoctorWithSpec(id);
                    var doc = await doctorrepo.GetByIDWithSpec(spec);
                    if (doc != null)
                    {
                        patient.doctors.Add(doc);
                    }
                }
            }
            await patientrepo.Additem(patient);
            return Ok("done");
        }

        [HttpGet]
        public async Task<ActionResult> getall()
        {
            var spec = new PatientWithSpec();
            var pat = await patientrepo.GetByIDWithSpec(spec);
            var patdto = mapper.Map < IEnumerable<Patiant>, IEnumerable<PatientReturnDto<Patiant>>>(Patiant);
            return Ok(patdto);
        }

        [HttpPut("{id}")]
        public async Task<ActionResult> update(int id,PatiantUpdatedto dto)
        {
            var spec= new PatientWithSpec();
            var pat = await patientrepo.GetByIDWithSpec(spec);
            if(!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            if(pat==null)
            {
                return NotFound("not");
            }
            if((dto.doctorid!=null))
             {
              
                    pat.doctors = new List<Doctor>();

                foreach(var did in dto.doctorid)
                {
                    var spc = new DoctorWithSpec(id);
                    var do= await doctorrepo.GetByIDWithSpec(spec);
                    if(do!=null)
                     {

                    }
                   
                }

            }
            await patientrepo.update(pat);
            return Ok("done");
        }
    }
}
