﻿using AutoMapper;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using WebApplication14.Dto;
using WebApplication14.Generaric;
using WebApplication14.Models;
using WebApplication14.Specification;

namespace WebApplication14.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class DoctorController : ControllerBase
    {
        private readonly IGeneraicRepository<Doctor> doctorrepo;
        private readonly IGeneraicRepository<Departtment> departmentrepo;
        private readonly IMapper mapper;

        public DoctorController(IGeneraicRepository<Doctor>doctorrepo,IGeneraicRepository<Departtment>Departmentrepo,IMapper mapper)
        {
            this.doctorrepo = doctorrepo;
            departmentrepo = Departmentrepo;
            this.mapper = mapper;
        }

        [HttpPost]
        public async Task<ActionResult>AddDoctor(DoctorCreateDto dto)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            var spec = new DepartmentWithAllSpec(dto.Departmentid);
            var depaertment=  await departmentrepo.GetByIDWithSpec(spec);

            if(depaertment == null)
            {
                return NotFound("department id not found");

            }
            var doctor=mapper.Map<DoctorCreateDto,Doctor>(dto);
            await doctorrepo.Additem(doctor);
            return Ok("done");

        }



        [HttpGet("{id}")]
        public async Task<ActionResult>GetById(int id)
        {
            var spec = new DoctorWithSpec(id);
            var doctor=await doctorrepo.GetByIDWithSpec(spec);
            if(doctor == null)
            {
                return NotFound("doc not found");
            }
            var doctordto=mapper.Map<Doctor,octorReturnDto>(doctor);
            return Ok(doctordto);
        }



    }
}
