﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace WebApplication14.Models
{
    public class Patiant
    {
        public int Id { get; set; }

        [Required]
        [MaxLength(100)]
        public string Name { get; set; }

        public string Email { get; set; }

        public ICollection<Doctor> doctors { get; set; }= new List<Doctor>();
        
        [ForeignKey("Medical")]
        public int? MedicalId { get; set; }
        public Medical Medical { get; set; }

    }
}
