﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace WebApplication14.Models
{
    public class Doctor
    {
        public int Id { get; set; }
        [Required]
        [MaxLength(100)]
        public string Name { get; set; }
        [EmailAddress]
        public string Email { get; set; }
        [Phone]
        public string? Phone {  get; set; }

        public ICollection<Patiant>patiants { get; set; }=new List<Patiant>();

        [ForeignKey("Departtment")]
        public int Departmentid {  get; set; }
        public Departtment Department {  get; set; }



    }
}
