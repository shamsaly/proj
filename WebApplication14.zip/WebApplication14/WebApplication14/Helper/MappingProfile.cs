﻿using AutoMapper;
using WebApplication14.Dto;
using WebApplication14.Models;

namespace WebApplication14.Helper
{
    public class MappingProfile:Profile
    {

        public MappingProfile()
        {

            CreateMap<DepartmentCreateDto, Departtment>();
            CreateMap<DoctorCreateDto, Doctor>();
            CreateMap<Doctor, octorReturnDto>()
                .ForMember(f => f.DepartmentName, c => c.MapFrom(a => a.Department.Name));
            CreateMap<MedicalCreateDto, Medical>();

            CreateMap<PatientCreateDTO, Patiant>()
                .ForMember(s => s.doctors, p => p.Ignore());
            CreateMap<Medical, MedicalCreateDto>();
              CreateMap<Patiant,PatientReturnDto>()
                .ForMember(V=>V.doctors,o => o.MapFrom(d=>d.doctors));

            CreateMap<Doctor, DoctorReturnDtoForPatient>();
            CreateMap<PatiantUpdatedto, Patiant>()
                .ForMember(w => w.doctors, o => o.Ignore());




        }






    }
}
