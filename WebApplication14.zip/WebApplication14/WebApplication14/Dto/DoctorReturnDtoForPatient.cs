﻿using System.ComponentModel.DataAnnotations;

namespace WebApplication14.Dto
{
    public class DoctorReturnDtoForPatient
    {

       
        public string Name { get; set; }
   
        public string Email { get; set; }
        
        public string Phone { get; set; }


    }
}
