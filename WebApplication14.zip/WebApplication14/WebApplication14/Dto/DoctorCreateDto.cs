﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using WebApplication14.Models;

namespace WebApplication14.Dto
{
    public class DoctorCreateDto
    {
        [Required(ErrorMessage ="name is reuired")]
        [MaxLength(100)]
        public string Name { get; set; }
        [EmailAddress(ErrorMessage ="enter valid email")]
        public string Email { get; set; }
        [Phone]
        public string? Phone { get; set; }
        [Required(ErrorMessage ="department id required")]
        public int Departmentid { get; set; }



    }
}
