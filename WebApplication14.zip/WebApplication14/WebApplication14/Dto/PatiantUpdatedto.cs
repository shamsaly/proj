﻿using System.ComponentModel.DataAnnotations;

namespace WebApplication14.Dto
{
    public class PatiantUpdatedto
    {
        public int Id { get; set; }

        [Required]
        [MaxLength(100)]
        public string Name { get; set; }

        public string Email { get; set; }

        public List<int>? doctorid { get; set; }


        public MedicalCreateDto Medical { get; set; }
    }
}
