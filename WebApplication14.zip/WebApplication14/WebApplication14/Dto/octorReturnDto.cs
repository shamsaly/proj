﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using WebApplication14.Models;

namespace WebApplication14.Dto
{
    public class octorReturnDto
    {
        public int Id { get; set; }
      
        public string Name { get; set; }
   
        public string Email { get; set; }
      
        public string? Phone { get; set; }

        public string DepartmentName { get; set; }



    }
}
