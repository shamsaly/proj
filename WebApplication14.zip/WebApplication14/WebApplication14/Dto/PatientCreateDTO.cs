﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using WebApplication14.Models;

namespace WebApplication14.Dto
{
    public class PatientCreateDTO
    {

        public int Id { get; set; }

        [Required]
        [MaxLength(100)]
        public string Name { get; set; }

        public string Email { get; set; }

       public List<int>doctorid { get; set; }=new List<int>();


        public MedicalCreateDto? Medical { get; set; }


    }
}
