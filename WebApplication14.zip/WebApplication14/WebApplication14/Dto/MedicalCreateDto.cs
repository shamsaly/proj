﻿using System.ComponentModel.DataAnnotations;

namespace WebApplication14.Dto
{
    public class MedicalCreateDto
    {

        public int Id { get; set; }

        [MaxLength(100)]
        [Required]
        public string Model { get; set; }


    }
}
