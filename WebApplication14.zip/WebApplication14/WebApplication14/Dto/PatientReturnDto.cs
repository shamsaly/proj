﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using WebApplication14.Models;

namespace WebApplication14.Dto
{
    public class PatientReturnDto
    {

        public int Id { get; set; }

    
        public string Name { get; set; }

        public string Email { get; set; }

        public ICollection<DoctorReturnDtoForPatient> doctors { get; set; } = new List<DoctorReturnDtoForPatient>();

   
   
        public MedicalCreateDto Medical { get; set; }
    }
}
