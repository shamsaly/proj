﻿using System.ComponentModel.DataAnnotations;

namespace WebApplication14.Dto
{
    public class DepartmentCreateDto
    {

        [Required(ErrorMessage ="name is required and max lenght 50")]
        [MaxLength(50)]
        public string Name { get; set; }

        public string? Description { get; set; }



    }
}
