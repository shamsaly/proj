﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace WebApplication14.Migrations
{
    /// <inheritdoc />
    public partial class secound : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropIndex(
                name: "IX_patiant_MedicalId",
                table: "patiant");

            migrationBuilder.AlterColumn<int>(
                name: "MedicalId",
                table: "patiant",
                type: "int",
                nullable: true,
                oldClrType: typeof(int),
                oldType: "int");

            migrationBuilder.CreateIndex(
                name: "IX_patiant_MedicalId",
                table: "patiant",
                column: "MedicalId",
                unique: true,
                filter: "[MedicalId] IS NOT NULL");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropIndex(
                name: "IX_patiant_MedicalId",
                table: "patiant");

            migrationBuilder.AlterColumn<int>(
                name: "MedicalId",
                table: "patiant",
                type: "int",
                nullable: false,
                defaultValue: 0,
                oldClrType: typeof(int),
                oldType: "int",
                oldNullable: true);

            migrationBuilder.CreateIndex(
                name: "IX_patiant_MedicalId",
                table: "patiant",
                column: "MedicalId",
                unique: true);
        }
    }
}
