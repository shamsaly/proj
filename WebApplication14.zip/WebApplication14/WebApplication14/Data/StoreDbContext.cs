﻿using Microsoft.EntityFrameworkCore;
using WebApplication14.Models;

namespace WebApplication14.Data
{
    public class StoreDbContext:DbContext
    {

        public StoreDbContext (DbContextOptions<StoreDbContext> options) : base(options)
        { 
        
        }


       public DbSet<Doctor> doctor {  get; set; }
        public DbSet<Patiant> patiant { get; set; }
        public DbSet<Medical> medicical { get; set; }
        public DbSet<Departtment> departtment { get; set;}


        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Patiant>()
                .HasOne(p => p.Medical)
                .WithOne().OnDelete(DeleteBehavior.NoAction);







            base.OnModelCreating(modelBuilder);
        }

    }
}
