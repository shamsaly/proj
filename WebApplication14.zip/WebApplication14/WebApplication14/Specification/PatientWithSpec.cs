﻿using WebApplication14.Models;

namespace WebApplication14.Specification
{
    public class PatientWithSpec:BaseSpecification<Patiant>
    {

        public PatientWithSpec():base()
        {
            Includes.Add(p => p.doctors);
            Includes.Add(p => p.Medical);

        }

        public PatientWithSpec(int id) : base(s=>s.Id==id)
        {
            Includes.Add(propa => propa.doctors);
            Includes.Add(propa => propa.Medical);

        }

    }
}
