﻿using Microsoft.EntityFrameworkCore;

namespace WebApplication14.Specification
{
    public class SpecifucationEvalouater<T>where T : class
    {
        public static IQueryable<T> GetQuerry(IQueryable<T> startquerry, ISpecifaction<T> spec)
        {
            var query = startquerry;
            if(spec.condition != null) 
            {
            query=query.Where(spec.condition);  


            }
            query = spec.Includes.Aggregate(query, (current, next) => current.Include(next));
            return query;



        }
    }
}
