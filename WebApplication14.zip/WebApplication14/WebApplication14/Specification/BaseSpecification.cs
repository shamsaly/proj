﻿using System.Linq.Expressions;

namespace WebApplication14.Specification
{
    public class BaseSpecification<T>:ISpecifaction<T> where T : class
    {
        public Expression<Func<T, bool>> condition { get; set; }

     
        public List<Expression<Func<T, object>>> Includes { get; set; }=new List<Expression<Func<T, object>>>();        

        public BaseSpecification()
        {
            
        }
        public BaseSpecification(Expression<Func<T,bool>>expression)
        {
            condition= expression;



            
        }


    }
}
