﻿using WebApplication14.Models;

namespace WebApplication14.Specification
{
    public class DepartmentWithAllSpec:BaseSpecification<Departtment>
    {
        public DepartmentWithAllSpec() : base()
        {
            Includes.Add(d => d.Doctors);
            

        }
        public DepartmentWithAllSpec(int id) : base(d=>d.Id==id)
        {
            Includes.Add(d => d.Doctors);
        

        }

    }
}
