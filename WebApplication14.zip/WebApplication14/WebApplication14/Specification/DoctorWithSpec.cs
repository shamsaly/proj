﻿using WebApplication14.Models;

namespace WebApplication14.Specification
{
    public class DoctorWithSpec:BaseSpecification<Doctor>
    {

        public DoctorWithSpec():base()
        {
            Includes.Add(d=> d.Department);
            Includes.Add(d => d.patiants);

        }
        public DoctorWithSpec(int id) : base(a=>a.Id==id)
        {
            Includes.Add(d => d.Department);
            Includes.Add(d => d.patiants);

        }

    }
}
